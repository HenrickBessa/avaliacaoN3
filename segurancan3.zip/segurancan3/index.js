import http from 'http';
import express from 'express';
import cookieParser from 'cookie-parser';
import bodyParser from 'body-parser';
import cors from 'cors';
import {connectToMongoDB} from './connections/database_mongo.js';
import userRoutes from './routes/user_rt.js';
import reportRoutes from './routes/report/report_rt.js';

const app = express();

const port = 3000;

app.use(cookieParser());

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());

connectToMongoDB();

// const corsOptions = {
//     origin: "http://localhost:3000",
//     credentials: true
// };

// app.use(cors(corsOptions));

// userRoutes(app);
// reportRoutes(app);

app.listen(port, () => console.log(`Listening on port ${port}`));
