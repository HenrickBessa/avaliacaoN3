import LoginForm from "./login/page";

export default function Home() {
  return (
    <main>
      <div>
        <LoginForm />
      </div>
    </main>
  );
}
