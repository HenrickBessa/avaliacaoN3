import User from '../model/user_md.js'; // Note the .js extension
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import signatureController from './signature/signature_ct.js'; // Note the .js extension

const getUsers = async (req, res) => {
    try {
        const users = await User.find();
        res.status(200).json(users);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: `Internal server error: ${error}`});
    }
};

// Register a new user
const registerUser = async (req, res) => {
    try {
        const { name, email, password, type } = req.body;

        // Verificar se o nome de usuário já existe
        const existingUser = await User.findOne({ name });
        if (existingUser) {
            return res.status(400).json({ message: 'User with that name already exists' });
        }

        // Criar um novo usuário
        const newUser = new User({ name, email, password, type });

        // Gerar um salt para o hash da senha
        const salt = crypto.randomBytes(16).toString('hex');

        // Criar o hash da senha usando pbkdf2
        crypto.pbkdf2(password, salt, 1000, 64, 'sha512', async (err, derivedKey) => {
            if (err) throw err;

            newUser.password = derivedKey.toString('hex');
            newUser.salt = salt;

            // Salvar o usuário no banco de dados
            await newUser.save();

            // Criar chaves e assinatura para o usuário
            await signatureController.ensureKeysAndCreateSignature(newUser._id, newUser.name);

            res.status(201).json({ message: 'User registered successfully' });
        });

    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).json({ message: 'Failed to register user' });
    }
};

// Login a user
const loginUser = async (req, res) => {
    try {
        const { name, password } = req.body;

        // Find the user by name
        const user = await User.findOne({ name });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Verify the password
        const hashedPassword = crypto
            .pbkdf2Sync(password, user.salt, 1000, 64, 'sha512')
            .toString('hex');

        if (hashedPassword !== user.password) {
            return res.status(401).json({ message: 'Invalid password' });
        }

        // Generate a JWT token
        const token = jwt.sign({ _id: user._id, name: user.name, type: user.type }, 'secret', { expiresIn: '1h' });

        res.cookie("jwt", token, {
            httpOnly: true,
            maxAge: 3 * 60 * 60 * 500, // 3hrs in ms
        });

        res.status(200).json({ token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

const getCurrentUser = async (req, res) => {
    try {
        const token = req.cookies.jwt;
        const decoded = jwt.verify(token, 'secret');
        const user = await User.findById(decoded._id);
        res.status(200).json(user);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

export { registerUser, loginUser, getUsers, getCurrentUser };
