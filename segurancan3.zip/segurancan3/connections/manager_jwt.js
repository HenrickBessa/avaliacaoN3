import jwt from 'jsonwebtoken';

const jwtSecret = 'secret';

export const decodeUserInfo = (token) => {
  if (token) {
    try {
      let decoded = jwt.verify(token, jwtSecret);
      return decoded;
    } catch (e) {
      console.log(`Error decoding token: ${e}`);
      return null;
    }
  } else {
    console.log("No token found!");
    return null;
  }
};

export const diretorAuth = (req, res, next) => {
  const token = req.cookies.jwt;
  if (token) {
    jwt.verify(token, jwtSecret, (err, decodedToken) => {
      if (err) {
        res.status(401).send(`Error validating token: ${err}`);
      } else {
        if (decodedToken.type !== "Diretor") {
          res.status(401).send("Not authorized");
        } else {
          next();
        }
      }
    });
  } else {
    res.status(401).send("No token!");
  }
};

export const gerenteAuth = (req, res, next) => {
  const token = req.cookies.jwt;
  if (token) {
    jwt.verify(token, jwtSecret, (err, decodedToken) => {
      if (err) {
        res.status(401).send(`Error validating token: ${err}`);
      } else {
        if (decodedToken.type !== "Gerente" && decodedToken.type !== "Diretor") {
          res.status(401).send("Not authorized");
        } else {
          next();
        }
      }
    });
  } else {
    res.status(401).send("No token!");
  }
};

export const colaboradorAuth = (req, res, next) => {
  const token = req.cookies.jwt;
  if (token) {
    jwt.verify(token, jwtSecret, (err, decodedToken) => {
      if (err) {
        res.status(401).send(`Error validating token: ${err}`);
      } else {
        if (decodedToken.type !== "Colaborador" && decodedToken.type !== "Gerente" && decodedToken.type !== "Diretor") {
          console.log(decodedToken.type);
          res.status(401).send("Not authorized");
        } else {
          next();
        }
      }
    });
  } else {
    res.status(401).send("No token!");
  }
};
