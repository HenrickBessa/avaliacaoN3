import mongoose from 'mongoose';

const connectToMongoDB = async () => {
    try {
        const mongoURI = 'mongodb+srv://bessa2002henrick:dxa0Po0XMmSijCop@cluster0.nnohfun.mongodb.net/';
        await mongoose.connect(mongoURI, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('Connected to MongoDB');
    } catch (error) {
        console.error('Could not connect to MongoDB:', error);
        process.exit(1); 
    }
};

export default connectToMongoDB;
