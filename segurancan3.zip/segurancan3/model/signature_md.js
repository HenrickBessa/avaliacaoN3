import mongoose from 'mongoose';

const signatureSchema = new mongoose.Schema({
    user_id: {
        type: String,
        required: true
    },
    publicKey: {
        type: String,
        required: true
    },
    privateKey: {
        type: String,
        required: true
    },
    // Outros campos relacionados à assinatura digital
    createdAt: {
        type: Date,
        default: Date.now
    }
}, { collection: 'signature' });

const DigitalSignature = mongoose.model('Signature', signatureSchema);

export default DigitalSignature;
