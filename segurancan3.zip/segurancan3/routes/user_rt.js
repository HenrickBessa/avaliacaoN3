import express from 'express';
import UserController from '../controller/user_ct.js'; 
import jwtRules from '../connections/manager_jwt.js';

const router = express.Router();

// GET /users
router.post('/users', jwtRules.gerenteAuth, UserController.getUsers);

// POST /users
router.post('/register', jwtRules.gerenteAuth, UserController.registerUser);

router.post('/users/current', UserController.getCurrentUser);

// POST /login
router.post('/login', UserController.loginUser);

const userRoutes = (app) => {
    app.use(router);
};

export default userRoutes;
