import express from 'express';
import ReportController from '../../controller/report/report_ct.js';
import { colaboradorAuth, gerenteAuth, diretorAuth } from '../../connections/manager_jwt.js';

const router = express.Router();

// GET all reports
router.get('/reports', colaboradorAuth, ReportController.getAllReports);

// GET report by ID
router.get('/reports/:id', colaboradorAuth, ReportController.getReportById);

// POST create a new report
router.post('/reports', colaboradorAuth, ReportController.createReport);

// PUT sign a report
router.put('/reports/:id/sign', gerenteAuth, ReportController.signReport);

// PUT validate a report
router.put('/reports/:id/validate', diretorAuth, ReportController.validateReport);

// POST generate PDF for a report
router.post('/reports/:id/pdf', colaboradorAuth, ReportController.generatePDF);

export default router;
